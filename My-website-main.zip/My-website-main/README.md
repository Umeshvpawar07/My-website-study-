# My-website
Optional
<!DOCTYPE html>
<html>
<head>
 <title>My Simple Website</title>
</head>
<body>
 <h1>Welcome to My Website</h1>
 <p>This is hosted using GitHub Pages!</p>
</body>
</html>
